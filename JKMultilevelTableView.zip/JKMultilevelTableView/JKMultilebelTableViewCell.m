//
//  JKMultilebelTableViewCell.m
//  JKMultilevelTableViewCell
//
//  Created by qiyun on 15/11/6.
//  Copyright © 2015年 com.application.qiyun. All rights reserved.
//

#import "JKMultilebelTableViewCell.h"

@implementation JKMultilebelTableViewCell


//数据填充
- (void)fillDataWithMultilevelModel:(JKMultilevelModel *)model{

    self.textLabel.text = model.titleString;

    self.detailTextLabel.text = model.subTitleString;

    self.tag = model.tagValue;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
