//
//  JKMultilevelTableView.m
//  JKMultilevelTableViewCell
//
//  Created by qiyun on 15/11/5.
//  Copyright © 2015年 com.application.qiyun. All rights reserved.
//

#import "JKMultilevelTableView.h"

#define kJKMultilevelCellHeight 44.0f
#define LOAD_IMAGE(file,ext) [UIImage imageWithContentsOfFile:[[NSBundle mainBundle]pathForResource:file ofType:ext]]

@interface JKMultilevelTableView (UITableView)

//是否展开
@property (nonatomic,assign)    BOOL    showSubview;


@end


@implementation JKMultilevelTableView

{
    NSMutableArray      *_subTitleDataArray;
}

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{

    self = [super initWithFrame:frame style:style];

    if (self) {

        self.unfoldSubViewArray = [NSMutableArray array];

        _subTitleDataArray = [NSMutableArray array];

        [self configureView];
    }
    return self;
}

#pragma mark    -   Private Method

- (void)configureView{

    self.delegate                       = self;
    self.dataSource                     = self;
    self.separatorColor                 = [UIColor purpleColor];
    self.showsVerticalScrollIndicator    = NO;
    self.tableFooterView = [UIView new];
}

/*!
 *  展开第一行
 */
- (void)setUnfoldSection:(BOOL)unfoldSection{

    _unfoldSection = unfoldSection;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

        [self sectionClick:nil];
    });
}

#pragma mark    -   Custom Method



#pragma mark    -   System Delegate

#pragma mark  ------------UITableView Delegate and Datasource

//设置每组多少行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    NSString *sectionString = [NSString stringWithFormat:@"%ld",section];

    //展开
    if ([_unfoldSubViewArray containsObject:sectionString] && (section != 0)) {

        UIImageView *aIV = (UIImageView *)[tableView viewWithTag:section + 1000];

        [UIView animateWithDuration:0.5 animations:^{

            aIV.transform = CGAffineTransformMakeRotation(2*M_PI);

        } completion:^(BOOL finished) {

            aIV.image = LOAD_IMAGE(@"grzx-jt-x", @"png");
        }];

        return 3;
    }else{

        UIImageView *aIV = (UIImageView *)[tableView viewWithTag:section + 1000];

        [UIView animateWithDuration:0.5 animations:^{

            aIV.transform = CGAffineTransformMakeRotation(2*M_PI);

        } completion:^(BOOL finished) {

            aIV.image = LOAD_IMAGE(@"grzx-jt-z", @"png");
        }];
        return 0;
    }
}



//设置多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return _titleArray.count + 1;
}



//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return kJKMultilevelCellHeight;
}



//配置cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static  NSString    *cellIdentifier = @"cellIdentifier";

    JKMultilebelTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];

    if (!cell) {

        cell = [[JKMultilebelTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }

    NSLog(@"section = %ld row = %ld",indexPath.section,indexPath.row);

    JKMultilevelModel *model = (JKMultilevelModel *)_subTitleDataArray[MIN(indexPath.section-1, _subTitleDataArray.count)][indexPath.row];


    [cell fillDataWithMultilevelModel:model];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    NSLog(@"click...");
}

//每个头标题栏的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

    if (section== 0)    return 80.0f;

    return kJKMultilevelCellHeight;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    return 1.0f;
}


//配置头标题视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    if (section >= 1) {

        UIView *headerView  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, kJKMultilevelCellHeight)];
        headerView.userInteractionEnabled   = YES;
        headerView.backgroundColor          = [UIColor orangeColor];
        headerView.tag                      = section;

        //标题
        UILabel *label      = [[UILabel alloc] initWithFrame:CGRectMake(10, 12, 100, 20)];
        label.text          = _titleArray[MIN(section-1, _titleArray.count -1)];
        label.textColor     = [UIColor whiteColor];
        [headerView addSubview:label];

        //子标题
        UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(tableView.frame.size.width - 160, 12, 120, 20)];
        label2.text             = _subTitleArray[MIN(section-1, _subTitleArray.count - 1)];
        label2.textColor        = [UIColor whiteColor];
        label2.textAlignment    = NSTextAlignmentRight;
        [headerView addSubview:label2];



        UIImageView *accessoryIV = [[UIImageView alloc] initWithFrame:CGRectMake(tableView.frame.size.width - 25, 14, 8, 16)];
        accessoryIV.image = LOAD_IMAGE(@"grzx-jt-z", @"png");
        accessoryIV.tag          = 1000 + section;
        [headerView addSubview:accessoryIV];

        UITapGestureRecognizer  *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                               action:@selector(sectionClick:)];
        
        [headerView addGestureRecognizer:tap];

        return headerView;
    }else{

        return self.oneHeaderView;
    }
}



#pragma mark    -   Custom Delegate



#pragma mark    -   Response Method

//点击cell标题响应方法
- (void)sectionClick:(UITapGestureRecognizer *)tapValue{

    NSInteger section = tapValue.view.tag;
    NSLog(@"sectionString = %ld",section);

    if (_unfoldSection)     section = 1;

    NSString *sectionString = [NSString stringWithFormat:@"%ld",section];

    NSIndexPath *indexPathOne = [NSIndexPath indexPathForRow:0 inSection:section];
    NSIndexPath *indexPathTwo = [NSIndexPath indexPathForRow:1 inSection:section];
    NSIndexPath *indexPathThree = [NSIndexPath indexPathForRow:2 inSection:section];

    NSArray *indexPaths = @[indexPathOne,indexPathTwo,indexPathThree];


    //展开
    if (![self.unfoldSubViewArray containsObject:sectionString]) {

        [self.unfoldSubViewArray addObject:sectionString];

        [self insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];

        _unfoldSection = NO;
    }

    //缩回
    else{

        [self.unfoldSubViewArray removeObject:sectionString];

        [self deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationBottom];

    }
}



#pragma mark    -   set/get method

- (void)setTitleArray:(NSMutableArray *)titleArray{

    _titleArray = titleArray;

    [_unfoldSubViewArray removeAllObjects];

    [_showSubviewArray addObject:_titleArray];

    [self reloadData];
}


- (void)setSubTitleArray:(NSMutableArray *)subTitleArray{

    _subTitleArray = subTitleArray;
}


- (void)setTwoLevelTitleArray:(NSMutableArray *)twoLevelTitleArray{

    _twoLevelTitleArray = twoLevelTitleArray;
}


- (void)setTwoLevelSubTitleArray:(NSMutableArray *)twoLevelSubTitleArray{

    _twoLevelSubTitleArray = twoLevelSubTitleArray;

    [_twoLevelSubTitleArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {

        NSMutableArray  *modelArray = [NSMutableArray array];

        [obj enumerateObjectsUsingBlock:^(id  _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {

            JKMultilevelModel *model = [[JKMultilevelModel alloc] init];

            model.titleString = _twoLevelTitleArray[idx][idx2];
            model.subTitleString = obj2;

            [modelArray addObject:model];
        }];

        [_subTitleDataArray addObject:modelArray];
    }];

    //[self reloadData];
}


- (void)setShowSubviewArray:(NSMutableArray *)showSubviewArray{

    _showSubviewArray = showSubviewArray;
}


- (void)setOneHeaderView:(UIView *)oneHeaderView{

    _oneHeaderView = oneHeaderView;

    NSIndexSet *set = [[NSIndexSet alloc] initWithIndex:0];

    [self reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
}



@end
