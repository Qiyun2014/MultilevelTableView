//
//  JKMultilebelTableViewCell.h
//  JKMultilevelTableViewCell
//
//  Created by qiyun on 15/11/6.
//  Copyright © 2015年 com.application.qiyun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKMultilevelModel.h"

@interface JKMultilebelTableViewCell : UITableViewCell


//数据填充
- (void)fillDataWithMultilevelModel:(JKMultilevelModel *)model;


@end
