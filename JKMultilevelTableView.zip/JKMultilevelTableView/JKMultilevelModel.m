//
//  JKMultilevelModel.m
//  JKMultilevelTableViewCell
//
//  Created by qiyun on 15/11/6.
//  Copyright © 2015年 com.application.qiyun. All rights reserved.
//

#import "JKMultilevelModel.h"

@implementation JKMultilevelModel


@synthesize titleString,subTitleString,unfold;


@end
