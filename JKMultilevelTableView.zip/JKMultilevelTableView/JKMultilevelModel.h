//
//  JKMultilevelModel.h
//  JKMultilevelTableViewCell
//
//  Created by qiyun on 15/11/6.
//  Copyright © 2015年 com.application.qiyun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JKMultilevelModel : NSObject


//是否展开
@property (nonatomic,assign) BOOL   unfold;


//cell的tag
@property (nonatomic,assign) NSInteger  tagValue;


//主标题文字
@property (nonatomic,copy)  NSString    *titleString;


//副标题文字
@property (nonatomic,copy)  NSString    *subTitleString;



@end
