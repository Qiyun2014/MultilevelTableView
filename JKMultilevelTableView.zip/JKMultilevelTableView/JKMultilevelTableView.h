//
//  JKMultilevelTableView.h
//  JKMultilevelTableViewCell
//
//  Created by qiyun on 15/11/5.
//  Copyright © 2015年 com.application.qiyun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKMultilevelModel.h"
#import "JKMultilebelTableViewCell.h"

@interface JKMultilevelTableView : UITableView<UITableViewDataSource,UITableViewDelegate>

//第一行的视图
@property (nonatomic,strong) UIView     *oneHeaderView;


//是否展开第一行,默认不展开
@property (nonatomic,assign) BOOL       unfoldSection;


//设置头标题的文字
@property (nonatomic,strong) NSMutableArray     *titleArray;

//设置头标题的子标题的文字
@property (nonatomic,strong) NSMutableArray     *subTitleArray;

//设置子标题的文字
@property (nonatomic,strong) NSMutableArray     *twoLevelTitleArray;

//设置子标题的子标题的文字
@property (nonatomic,strong) NSMutableArray     *twoLevelSubTitleArray;

//展开的数组数据集合
@property (nonatomic,strong)    NSMutableArray  *showSubviewArray;

//展开的子视图
@property (nonatomic,strong)    NSMutableArray  *unfoldSubViewArray;


@end
